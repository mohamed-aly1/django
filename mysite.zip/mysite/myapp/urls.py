
from django.urls import path, include
from . import views 

urlpatterns = [
    
    path("home/", views.home , name="home"),
    path("menu/", views.menu , name="menu"),
    path("profile/",views.profile, name="profile"),
    path('cart/', views.add_to_cart, name='add_to_cart'),
    path("signup/" ,views.register , name="signup"),
    path("login/",views.login, name="login")
    ]
    
