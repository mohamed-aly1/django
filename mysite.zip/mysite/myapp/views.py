from django.shortcuts import  render, redirect
from .forms import LoginForm
from .models import MyUserModel ,Product

def register(request):
    username = request.POST.get('username')
    email = request.POST.get('email')
    password = request.POST.get('password')
    address =request.POST.get('address')
    phone = request.POST.get('phone')  

    data = MyUserModel(Email=email, Username=username, Password=password , Address=address, Phone=phone)
    data.save()
    return render(request, 'myapp/signup.html') 
    
    
def login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = MyUserModel.objects.filter(Username=username, Password=password).first()
            if user:
                # set user session
                request.session['user_id'] = user.id
                return redirect('home')
            else:
                # invalid login
                return render(request, 'myapp/login.html', {'form': form, 'error': 'Invalid login credentials.'})
    else:
        form = LoginForm()
        return render(request, 'myapp/login.html', {'form': form})           


         


def home(request):
    return render(request ,"myapp/home.html")

def menu(request):
    items = Product.objects.all()
    cont = { "items" : items}
    return render(request ,"myapp/menu.html" , cont )


def profile(request):
    user_id = request.session['user_id']
    user = MyUserModel.objects.get(id=user_id)
    return render(request, 'myapp/profile.html', {'user': user})

def add_to_cart(request):
    return render(request , "myapp/cart.html")